# 安徽大学硕士学位论文LaTeX模板（本人已毕业，此项目停更）

本项目改自[BUAAThesis](https://github.com/CheckBoxStudio/BUAAThesis#%E5%8C%97%E4%BA%AC%E8%88%AA%E7%A9%BA%E8%88%AA%E5%A4%A9%E5%A4%A7%E5%AD%A6%E5%AD%A6%E4%BD%8D%E8%AE%BA%E6%96%87latex%E6%A8%A1%E6%9D%BF)，感谢他们的工作。

主要改了cls文件中的格式。

不保证和官方要求的格式完全一致，请自行斟酌使用。

希望后续能有人改进和完善，也希望隔壁计科院多做些事。

## 本人运行环境

MikTex+WinEdt

## 已知bug

1，双导师模式
